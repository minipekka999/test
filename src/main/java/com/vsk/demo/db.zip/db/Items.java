package com.vsk.demo.db;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
//@Entity
public class Items {

    private Long id;
    private String name;
    private Long price;
    private int amount;

}
