//package com.vsk.demo.db;
//
//import java.sql.*;
//import java.util.ArrayList;
//public class DBManager {
//    private static Connection connection;
//
//    static{
//        String url = "jdbc:postgresql://localhost:5432/narxoz";
//        String user = "postgres";
//                String password = "4vb9*$";
//        try{
//
//            Class.forName("org.postgresql.Driver");
//            connection= DriverManager.getConnection(url,user,password);
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//    public static ArrayList<Items> getItems(){
//
//        ArrayList<Items> items= new ArrayList<>();
//
//        try {
//
//            PreparedStatement s=connection.prepareStatement("" +
//                    "SELECT * FROM items ORDER BY id");
//            ResultSet r=s.executeQuery();
//
//            while (r.next()){
//                Long id = r.getLong("id");
//                String name= r.getString("name");
//                Long price = r.getLong("price");
//                int amount = r.getInt("amount");
//
//                Items item=new Items();
//                item.setId(id);
//                item.setName(name);
//                item.setPrice(price);
//                item.setAmount(amount);
//
//                items.add(item);
//
////                System.out.println(id+" "+name+" "+price+" "+amount);
//            }
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        return items;
//    }
//
//    public static void addI(Items item) throws SQLException {
//        try {
//
//
//            PreparedStatement stat4 = connection.prepareStatement("" +
//                    "INSERT INTO items(name, price, amount) VALUES(?,?,?)");
//            stat4.setString(1, item.getName());
//            stat4.setLong(2, item.getPrice());
//            stat4.setInt(3, item.getAmount());
//
////        stat4.executeUpdate();
////        stat4.close();
//
//            ResultSet o = stat4.executeQuery();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    public static Items getItem(Long id){
//
//        Items item=null;
//
//        try {
//            PreparedStatement s=connection.prepareStatement("" +
//                    "SELECT * FROM Items WHERE id= ?");
//            s.setLong(1,id);
//
//            ResultSet r = s.executeQuery();
//
//            if(r.next()){
//
//                String name= r.getString("name");
//                Long price = r.getLong("price");
//                int amount = r.getInt("amount");
//
//                item=new Items();
//                item.setId(id);
//                item.setName(name);
//                item.setPrice(price);
//                item.setAmount(amount);
//            }
//            s.close();
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        return item;
//    }
//
//    public static void saveItem(Items item) throws SQLException {
//        PreparedStatement s=connection.prepareStatement("UPDATE Items SET name = ?, price=?, amount=? WHERE id =?");
//        s.setString(1, item.getName());
//        s.setLong(2,item.getPrice());
//        s.setInt(3,item.getAmount());
//        s.setLong(4,item.getId());
//
//        s.executeUpdate();
//        s.close();
//
////        ResultSet o = s.executeQuery();
//    }
//
//    public static void deleteItem(Items item){
//
//        try {
//            PreparedStatement s=connection.prepareStatement("DELETE FROM Items WHERE id=?");
//
//            s.setLong(1,item.getId());
//            s.executeUpdate();
//            s.close();
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//    }
//
//
//}
