package com.vsk.demo.entities;

import static org.junit.jupiter.api.Assertions.*;

class ShopItemsTest {

}